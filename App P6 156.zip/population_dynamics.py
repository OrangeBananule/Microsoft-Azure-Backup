# -*- coding: utf-8 -*-
"""
Created on Thu Sep 13 13:49:13 2018

@author: Cerx
"""

import numpy as np
import matplotlib.pyplot as plt

def f(x,r):
    return 4*r*x*(1-x)

n = list(range(41))
y = []
x0 = .65
r = .87
x_temp = x0

for i in n:
    y.append(x_temp)
    x_temp = f(x_temp,r)

plt.figure('x(n) vs n')
plt.plot(n,y)

y1 = []
y2 = []
y4 = []
x = np.linspace(0,1,1001)
for i in x:
    y1.append(f(i,r))
    y2.append(f(f(i,r),r))
    y4.append(f(f(f(f(i,r),r),r),r))
plt.figure('n-fold iteration of x in f(x)')
plt.plot(x,x, label = 'straight line')
plt.plot(x,y1, label = 'one-fold')
plt.plot(x,y2, label = 'two-fold')
plt.plot(x,y4, label = 'four-fold')
plt.legend()

plt.figure('Feigenbaum')
xn = x0
x_space = []
for i in np.linspace(0,1,101):
    x_space.clear()
    for j in range(1001):
        xn = f(xn,i)
        x_space.append(xn)
    for k in range(100):
        x_space.pop(0)
        #remove first 100 values
    for space in x_space:
        plt.plot(i,space, c='r', marker = '.')
    xn = x0
