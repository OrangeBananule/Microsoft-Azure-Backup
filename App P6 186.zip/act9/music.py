# -*- coding: utf-8 -*-
"""
Created on Sat Sep 21 20:38:19 2019

@author: Cerx
"""
import numpy as np
import winsound

frequency = 278 # Set Frequency To 2500 Hertz
duration = 1000 # Set Duration To 1000 ms == 1 second

winsound.Beep(frequency, duration)
winsound.Beep(2*frequency, duration)

#for n in range(12):    
#    winsound.Beep(round(frequency * 2**(n/12)), duration)

#let's play Canon in C
#n = change key signature
a = 2
test = []
for n in [4 + a,2 + a,0 + a,-1 + a,-3 + a,-5 + a,-3 + a,-1 + a]:    
    winsound.Beep(round(frequency * 2**(n/12)), duration)
